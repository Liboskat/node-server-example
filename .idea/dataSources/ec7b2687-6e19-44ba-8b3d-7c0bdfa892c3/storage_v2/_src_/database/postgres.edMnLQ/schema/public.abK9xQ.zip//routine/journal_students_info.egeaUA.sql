create function journal_students_info(_journal_id integer)
  returns TABLE(student_name character varying, student_surname character varying, student_patronymic character varying, student_status character varying)
language plpgsql
as $$
BEGIN
  RETURN QUERY
  SELECT user_name              AS student_name,
         user_surname           AS student_surname,
         user_patronymic        AS student_patronymic,
         journal_student_status AS student_status
  FROM (
         SELECT journal_student_id, journal_student_status
         FROM journal_info
         WHERE journal_id = _journal_id
       ) AS student_statuses
    NATURAL JOIN (
                   SELECT user_id AS journal_student_id, user_name, user_surname, user_patronymic
                   FROM "user"
                 )	AS students;
END;
$$;

