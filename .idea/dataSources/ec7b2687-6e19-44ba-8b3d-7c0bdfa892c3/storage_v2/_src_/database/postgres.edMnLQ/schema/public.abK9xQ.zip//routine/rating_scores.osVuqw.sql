create function rating_scores(_student_id integer, _semester_number integer)
  returns TABLE(subject_name character varying, semester_score smallint, session_score smallint)
language plpgsql
as $$
BEGIN
  RETURN QUERY
  SELECT rating_subjects.subject_name,
    subjects_scores.semester_score,
    subjects_scores.session_score
  FROM public.subjects_scores
    INNER JOIN public.rating_subjects ON subjects_scores.subject_id = rating_subjects.subject_id
  WHERE subjects_scores.student_id = _student_id AND
        semester_number = _semester_number;
END
$$;

