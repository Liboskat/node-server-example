create function journal_subjects(_study_date date, _group_name character varying)
  returns TABLE(journal_id integer, subject_name character varying)
language plpgsql
as $$
BEGIN
  RETURN QUERY
  SELECT journal_id,
    journal_subject_name AS subject_name
  FROM (
         SELECT journal_subject_name, journal_group_id, journal_id
         FROM journal
         WHERE journal_date = _study_date
       ) AS subjects
    NATURAL JOIN (
                   SELECT group_id AS journal_group_id
                   FROM "group"
                   WHERE group_name = _group_name
                 ) AS given_group;
END
$$;

